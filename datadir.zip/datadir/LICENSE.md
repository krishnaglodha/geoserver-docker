The styles and related graphics available in this repository are released under the terms of the [Creative Commons Attribution-ShareAlike 4.0 International license](https://creativecommons.org/licenses/by-sa/4.0/) which means that you are free to:

* Share — copy and redistribute the material in any medium or format
* Adapt — remix, transform, and build upon the material for any purpose, even commercially.
 
The licensor (us) cannot revoke these freedoms as long as you follow the license terms.

![CC-BY-SA](https://i.creativecommons.org/l/by-sa/4.0/88x31.png)
